package com.parking.demo_part_api.services.exceptions;

public class CpfUniqueViolationException extends RuntimeException{

    public CpfUniqueViolationException(String message) {
        super(message);
    }
}
