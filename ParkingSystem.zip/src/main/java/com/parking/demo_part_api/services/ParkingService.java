package com.parking.demo_part_api.services;

import com.parking.demo_part_api.entities.Client;
import com.parking.demo_part_api.entities.ParkingSpaceClient;
import com.parking.demo_part_api.entities.ParkingSpaces;
import com.parking.demo_part_api.entities.enums.ParkingSpaceStatus;
import com.parking.demo_part_api.util.ParkingUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class ParkingService {

    private final com.parking.demo_part_api.services.ParkingSpaceClientService parkingSpaceClientService;
    private final ClientService clientService;
    private final com.parking.demo_part_api.services.ParkingSpacesService parkingSpacesService;

    @Transactional
    public ParkingSpaceClient checkIn(ParkingSpaceClient spaceClient) {

        Client client = clientService.findByCpf(spaceClient.getClient().getCpf());
        spaceClient.setClient(client);

        ParkingSpaces parkingSpaces = parkingSpacesService.findFreeParkingSpot();
        parkingSpaces.setStatus(ParkingSpaceStatus.OCCUPED);
        spaceClient.setParkingSpaces(parkingSpaces);

        spaceClient.setCheckInDate(LocalDateTime.now());
        spaceClient.setReceipt(ParkingUtils.generateReceipt());

        return parkingSpaceClientService.insert(spaceClient);
    }

    @Transactional
    public ParkingSpaceClient checkOut(String receipt) {
        ParkingSpaceClient parkingSpaceClient = parkingSpaceClientService.findByReceipt(receipt);

        LocalDateTime checkOutDate = LocalDateTime.now();

        BigDecimal value = ParkingUtils.calculateValue(parkingSpaceClient.getCheckInDate(), checkOutDate);
        parkingSpaceClient.setValue(value);

        long numberOfTimes = parkingSpaceClientService.getNumberOfTimes(parkingSpaceClient.getClient().getCpf());
        BigDecimal discount =  ParkingUtils.calculateDiscount(value, numberOfTimes);

        parkingSpaceClient.setDiscount(discount);
        parkingSpaceClient.setCheckOutDate(checkOutDate);
        parkingSpaceClient.getParkingSpaces().setStatus(ParkingSpaceStatus.FREE);

        return parkingSpaceClientService.insert(parkingSpaceClient);
    }
}
