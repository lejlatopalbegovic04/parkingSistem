package com.parking.demo_part_api.services.exceptions;

public class CodeUniqueViolationException extends RuntimeException{

    public CodeUniqueViolationException(String message){
        super(message);
    }
}
