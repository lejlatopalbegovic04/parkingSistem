package com.parking.demo_part_api.services.exceptions;

public class EntityNotFoundException extends RuntimeException {

    public EntityNotFoundException(Object id){
        super(" User  Not Found. id :" + id);
    }
}