package com.parking.demo_part_api.services.exceptions;

public class PasswordInvalidException extends RuntimeException{


    public PasswordInvalidException(String message) {
        super(message);
    }
}
