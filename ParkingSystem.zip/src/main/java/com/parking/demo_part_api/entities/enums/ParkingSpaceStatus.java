package com.parking.demo_part_api.entities.enums;

public enum ParkingSpaceStatus {
    OCCUPED,
    FREE
}
