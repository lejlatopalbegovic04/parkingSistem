package com.parking.demo_part_api.entities.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_CLIENT;
}
