package com.parking.demo_part_api.web.dto.mapper;

import com.parking.demo_part_api.entities.ParkingSpaceClient;
import com.parking.demo_part_api.web.dto.parkingDto.ParkingCreateDto;
import com.parking.demo_part_api.web.dto.parkingDto.ParkingResponseDto;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ParkingSpaceClientMapper {

    public static ParkingSpaceClient toParkingSpaceClient(ParkingCreateDto dto){
        return new ModelMapper().map(dto, ParkingSpaceClient.class);
    }

    public static ParkingResponseDto toDto(ParkingSpaceClient spaceClient){
        return new ModelMapper().map(spaceClient, ParkingResponseDto.class);
    }
}
