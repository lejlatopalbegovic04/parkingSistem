package com.parking.demo_part_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPartApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPartApiApplication.class, args);
	}

}
