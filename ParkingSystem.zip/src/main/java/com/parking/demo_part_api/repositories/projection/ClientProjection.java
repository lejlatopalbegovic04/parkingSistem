package com.parking.demo_part_api.repositories.projection;

public interface ClientProjection {

    Long getId();
    String getName();
    String getCpf();
}
